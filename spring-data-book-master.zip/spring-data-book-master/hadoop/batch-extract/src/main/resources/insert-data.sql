insert into product (id,name,description,price,update_timestamp) values('PR....214','Nokia 2610 Phone','A cell phone',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....215','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....216','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....217','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....218','Nokia 2610 Phone','',102.23,'2010-06-22 10:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....219','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....220','Nokia 2610 Phone','',102.23,'2010-06-21 09:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....221','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');
insert into product (id,name,description,price,update_timestamp) values('PR....222','Nokia 2610 Phone','',102.23,'2010-06-30 16:23:22.904');