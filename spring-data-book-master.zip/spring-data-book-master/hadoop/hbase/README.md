# Building and running

    $ mvn clean package appassembler:assemble
    $ sh ./target/appassembler/bin/usercount

