# Building and running

    $ cd hadoop/scheduling-quartz
    $ mvn clean package appassembler:assemble
    $ sh ./target/appassembler/bin/wordcount
